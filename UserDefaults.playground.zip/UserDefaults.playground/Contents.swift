import UIKit

protocol ObjectSavable {
    func setObject<Object>(_ object: Object, forKey: String) throws where Object: Encodable
    func getObject<Object>(forKey: String, castTo type: Object.Type) throws -> Object where Object: Decodable
}

enum ObjectSavableError: String, Error {
    case unableToEncode = "Unable to encode object"
    case noValue = "No value found with the associated key"
    case unableToCast = "Unable to cast fectched object into data"
    case unableToDecode = "Unable to decode object into provided type"
    
    var localizedDescription: String {
        self.rawValue
    }
}

extension UserDefaults: ObjectSavable {
    func setObject<Object>(_ object: Object, forKey: String) throws where Object: Encodable {
        let encoder = JSONEncoder()
        do {
            let data = try encoder.encode(object)
            let userDefaults = UserDefaults.standard
            userDefaults.set(data, forKey: forKey)
        } catch {
            throw(ObjectSavableError.unableToEncode)
        }
    }
    
    func getObject<Object>(forKey: String, castTo type: Object.Type) throws -> Object where Object: Decodable {
        let userDefaults = UserDefaults.standard
        guard let anyObj = userDefaults.object(forKey: forKey) else { throw(ObjectSavableError.noValue) }
        guard let data = anyObj as? Data else { throw(ObjectSavableError.unableToCast) }
        let decoder = JSONDecoder()
        do {
            let object = try decoder.decode(type.self, from: data)
            return object
        } catch {
            throw(ObjectSavableError.unableToDecode)
        }
    }
}

struct Book: Codable {
    var title: String
    var authorName: String
    var pageCount: Int
}

let playingItMyWay = Book(title: "Playing It My Way", authorName: "Sachin Tendulkar & Boria Mazumder", pageCount: 486)
let userDefaults = UserDefaults.standard

// Save
do {
    try userDefaults.setObject(playingItMyWay, forKey: "MyFavouriteBook")
} catch {
    print((error as! ObjectSavableError).localizedDescription)
}

// Fetch
do {
    let book = try userDefaults.getObject(forKey: "MyFavouriteBook", castTo: Book.self)
    print(book)
} catch {
    print((error as! ObjectSavableError).localizedDescription)
}

























